jQuery.fn.bgcolor = function () {
	return this.each (function () {
		$(this).css ("background-color", "orange");
	});
};
